<?php
/**
 * KNUT7 K7F (http://framework.artphoweb.com/)
 * KNUT7 K7F (tm) : Rapid Development Framework (http://framework.artphoweb.com/)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @link      http://github.com/zebedeu/artphoweb for the canonical source repository
 * @copyright (c) 2015.  KNUT7  Software Technologies AO Inc. (http://www.artphoweb.com)
 * @license   http://framework.artphoweb.com/license/new-bsd New BSD License
 * @author    Marcio Zebedeu - artphoweb@artphoweb.com
 * @version   1.0.2
 */



namespace Module\Upload;


use Ballybran\Helpers\Security\ValidateTypes;

/**
 * Class Upload
 * @package Module
 */
class ImageUpload
{
    /**
     * @var
     */
    private $id;

    /**
     * @var
     */
    private $path;
    /**
     * @var
     */
    private $name;
    /**
     * @var
     */
    private $size;
    /**
     * @var
     */
    private $type;

    /**
     * @return mixed
     */
    public function getPath() : string
    {
        return $this->path;
    }

    /**
     * @param mixed $path
     */
    public function setPath( $path )
    {
        $this->path = ValidateTypes::getSQLValueString($path, 'text');;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName( $name )
    {
        $this->name = ValidateTypes::getSQLValueString($name, 'text');;
    }

    /**
     * @return mixed
     */
    public function getSize()
    {
        return $this->size;
    }

    /**
     * @param mixed $size
     */
    public function setSize( $size )
    {

        $this->size = ValidateTypes::getSQLValueString($size, 'int');
    }

    /**
     * @return mixed
     */
    public function getType() : String
    {
        return $this->type;
    }

    /**
     * @param mixed $type
     */
    public function setType( $type )
    {
        $this->type = ValidateTypes::getSQLValueString($type, 'text');;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId( $id )
    {
        $this->id = ValidateTypes::getSQLValueString($id, 'int');;
    }



}