jQuery(document).ready(function(){
    // var lineChart = {
    //     type : "line",
    //     data : {
    //         datasets: [{
    //             data : [
    //                 3,10,40,12, 23,
    //             ],
    //
    //             backgroundColor: [
    //                 "#f7464a",
    //                 "#46BFBD",
    //                 "#FDB45C",
    //                 "#949FB1",
    //                 "#4D5360",
    //             ],
    //         }],
    //         labels : [
    //             "dados1",
    //             "dados2",
    //             "dados3",
    //             "dados4",
    //             "dados5",
    //         ]
    //     },
    //
    //     options : {
    //         responsive : true,
    //     }
    // };
    // var canvas = document.getElementById('popChart').getContext('2d');
    //
    // window.line = new Chart(canvas, lineChart);

    // var barChart = {
    //     type : "pie",
    //     data : {
    //         datasets: [{
    //             data : [
    //                 3,10,40,12, 23,
    //             ],
    //
    //             backgroundColor: [
    //                 "#f7464a",
    //                 "#46BFBD",
    //                 "#FDB45C",
    //                 "#949FB1",
    //                 "#4D5360",
    //             ],
    //         }],
    //         labels : [
    //             "dados1",
    //             "dados2",
    //             "dados3",
    //             "dados4",
    //             "dados5",
    //         ]
    //     },
    //
    //     options : {
    //         responsive : true,
    //     }
    // };
    // var bar = document.getElementById('barChart').getContext('2d');
    // window.line = new Chart(bar, barChart);



});





