<?php
/**
 * KNUT7 K7F (http://framework.artphoweb.com/)
 * KNUT7 K7F (tm) : Rapid Development Framework (http://framework.artphoweb.com/)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @link      http://github.com/zebedeu/artphoweb for the canonical source repository
 * @copyright (c) 2015.  KNUT7  Software Technologies AO Inc. (http://www.artphoweb.com)
 * @license   http://framework.artphoweb.com/license/new-bsd New BSD License
 * @author    Marcio Zebedeu - artphoweb@artphoweb.com
 * @version   1.0.2
 */


namespace Module\Lib;


use Ballybran\Database\Drives\AbstractDatabasePDO;
use Ballybran\Helpers\Event\Registry;
use Ballybran\Helpers\Security\Session;

class Notificacao extends AbstractDatabasePDO
{
    private $notification;

    /**
     * Visitor constructor.
     */
    function __construct()
    {
        parent::__construct(['dns'=>'mysql:host=localhost;dbname=apweb', 'pass'=>'root', 'users'=> 'root']);



    }

    public function funcListAtendido()
    {
        if(Session::exist()) {

            return $this->selectManager("SELECT Func_has_Paci.*, Paciente.*, Func_has_Paci.* , usuarios.* FROM Func_has_Paci INNER JOIN Paciente INNER JOIN Funcionarios ON Func_has_Paci.Funcionarios_id = Funcionarios.id AND Func_has_Paci.Paciente_id = Paciente.id INNER JOIN usuarios ON usuarios.id = Paciente.usuarios_id LEFT OUTER JOIN Medicamento ON Medicamento.Paciente_id = Paciente.id  WHERE Medicamento.Funcionarios_id is null  and Funcionarios.usuarios_id =" . Session::get('ID'));
        }
    }

    public function gerirConsulta()
    {
        return $this->selectManager('SELECT Func_has_Paci.*, Paciente.id, Paciente.info, usuarios.firstname, usuarios.lastname, usuarios.telephone, usuarios.role FROM Paciente INNER JOIN usuarios ON Paciente.usuarios_id = usuarios.id  left outer JOIN Func_has_Paci ON Func_has_Paci.Paciente_id = Paciente.id WHERE Func_has_Paci.Funcionarios_id is null AND Paciente.usuarios_id ORDER BY Paciente.id ASC');

    }

    public function gerirPaciente()
    {
        return $this->selectManager("SELECT usuarios.*, Paciente.info FROM usuarios LEFT OUTER JOIN Paciente ON usuarios.id = Paciente.usuarios_id WHERE usuarios.role = 'paciente' ");

    }


}