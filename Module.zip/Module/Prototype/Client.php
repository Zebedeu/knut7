<?php
/**
 * KNUT7 K7F (http://framework.artphoweb.com/)
 * KNUT7 K7F (tm) : Rapid Development Framework (http://framework.artphoweb.com/)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @link      http://github.com/zebedeu/artphoweb for the canonical source repository
 * @copyright (c) 2015.  KNUT7  Software Technologies AO Inc. (http://www.artphoweb.com)
 * @license   http://framework.artphoweb.com/license/new-bsd New BSD License
 * @author    Marcio Zebedeu - artphoweb@artphoweb.com
 * @version   1.0.2
 */

/**
 * Created by PhpStorm.
 * User: macbookpro
 * Date: 13/11/17
 * Time: 14:03
 */

namespace Module\Prototype;


class Client
{
    // direct instantion;
    private $fly1;
    private $fly2;

    private $c1fly;
    private $c2fly;

    private $updatedCloneFly;

    function __construct()
    {
        $this->fly1 = new MaleProto();
        $this->fly2 = new FemaleProto();

        // clone

        $this->c1fly = clone $this->fly1;
        $this->c2fly = clone $this->fly2;

        $this->updatedCloneFly = clone $this->fly2;

        // update

        $this->c1fly->meted = "true";
        $this->c2fly->fecundty ="186";

            $this->updatedCloneFly->eyeColor="purple";
            $this->updatedCloneFly->wingBeat="220";
            $this->updatedCloneFly->unitEyes="750";
            $this->updatedCloneFly->fecundity="92";
            //Send through type hinting method
            $this->showFly($this->c1fly);
            $this->showFly($this->c2fly);
            $this->showFly($this->updatedCloneFly);
}
    private function showFly(IPrototype $fly)
    {
        echo "Eye color: " . $fly->eyeColor . "<br/>";
        echo "Wing Beats/second: " . $fly->wingBeat . "<br/>";
        echo "Eye units: " . $fly->unitEyes . "<br/>";
        $genderNow=$fly::gender;
        echo "Gender: " . $genderNow . "<br/>";
        if($genderNow=="FEMALE")
        {
            echo "Number of eggs: " . $fly->fecundity . "<p/>";
        }
        else {
            echo "Mated: " . $fly->meted . "<p/>";
        }
    }
}
